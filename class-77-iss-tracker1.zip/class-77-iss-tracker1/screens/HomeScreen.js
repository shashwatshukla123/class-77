import * as React from 'react';
import {
  Text,
  View,
  StyleSheet,
  Image,
  Button,
  TouchableOpacity,
  ImageBackground,
} from 'react-native';

export default class HomeScreen extends React.Component {
  render() {
    return (
      <View style={styles.container}>
        <ImageBackground
          source={require('../assets/bg_image.png')}
          style={styles.backgroundImg}>
          <View style={styles.title}>
            <Text style={styles.titleText}>ISS Tracker App</Text>
          </View>
          <TouchableOpacity
            style={styles.button}
            onPress={() => this.props.navigation.navigate('Iss-Location')}>
            <Text style={styles.routeText}>ISS Location</Text>
            <Text style={styles.knowMore}>{'know more--->'}</Text>
            <Text style={styles.dgbg}>1</Text>
            <Image
              source={require('../assets/iss_icon.png')}
              style={styles.iconImg}
            />
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.button}
            onPress={() => this.props.navigation.navigate('Meteor')}>
            <Text style={styles.routeText}>Meteor</Text>
            <Text style={styles.knowMore}>{'know more--->'}</Text>
            <Text style={styles.dgbg}>2</Text>
            <Image
              source={require('../assets/meteor_icon.png')}
              style={styles.iconImg}
            />
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.button}
            onPress={() => this.props.navigation.navigate('Updates')}>
            <Text style={styles.routeText}>Updates</Text>
            <Text style={styles.knowMore}>{'know more--->'}</Text>
            <Text style={styles.dgbg}>3</Text>
            <Image
              source={require('../assets/rocket_icon.png')}
              style={styles.iconImg}
            />
          </TouchableOpacity>
        </ImageBackground>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  backgroundImg: {
    flex: 1,
    resizeMode: 'cover',
    width: '100%',
  },
  title: {
    flex: 0.15,
    justifyContent: 'center',
    alignContent: 'center',
  },
  titleText: {
    fontSize: 40,
    fontWeight: 'bold',
    color: 'white',
  },
  iconImg: {
    position: 'absolute',
    height: 200,
    width: 200,
    right: 20,
    top: -80,
    resizeMode: 'contain',
  },
  button: {
    
    flex: 0.25,
    marginLeft: 50,
    marginRight: 50,
    marginTop: 50,
    backgroundColor: 'white',
    borderRadius: 35,
  },
  routeText: {
    fontSize: 30,
    color: 'black',
    fontWeight: 'bold',
    marginTop: 50,
    paddingLeft: 20,
  },
  knowMore: {
    paddingLeft: 20,
    color: 'red',
    fontSize: 15,
  },
  dgbg: {
    position: 'absolute',
    fontSize: 70,
    color: 'blue',
    bottom: -15,
    paddingLeft: 150,
    zIndex: -1,
  },
});
